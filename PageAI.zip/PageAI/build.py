from pathlib import Path
import json, shutil

ROOT = Path(__file__).parent
SRC = ROOT / "src"

common = [
    "popup.html", "popup.css", "popup.js",
    "welcome.html", "welcome.css", "welcome.js",
    "content.js", "icons/pageai.svg"
]

def copy_common(dest):
    for name in common:
        target = dest / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SRC / name, target)

chrome = ROOT / "chromium"
firefox = ROOT / "firefox"
for folder in (chrome, firefox):
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)

copy_common(chrome)
copy_common(firefox)

chrome_manifest = {
    "manifest_version": 3,
    "name": "PageAI — Gemini Page Assistant",
    "version": "1.0.0",
    "description": "Ask Gemini about the webpage you're viewing.",
    "action": {"default_popup": "popup.html", "default_title": "PageAI"},
    "background": {"service_worker": "background.js"},
    "permissions": ["storage", "tabs", "scripting", "activeTab"],
    "host_permissions": ["https://generativelanguage.googleapis.com/*", "<all_urls>"],
    "content_scripts": [{
        "matches": ["<all_urls>"],
        "js": ["content.js"],
        "run_at": "document_idle"
    }],
    "options_page": "welcome.html",
    "icons": {"48": "icons/pageai.svg"}
}
firefox_manifest = {
    "manifest_version": 2,
    "name": "PageAI — Gemini Page Assistant",
    "version": "1.0.0",
    "description": "Ask Gemini about the webpage you're viewing.",
    "browser_action": {"default_popup": "popup.html", "default_title": "PageAI"},
    "background": {"scripts": ["background.js"]},
    "permissions": ["storage", "tabs", "activeTab", "https://generativelanguage.googleapis.com/*", "<all_urls>"],
    "content_scripts": [{
        "matches": ["<all_urls>"],
        "js": ["content.js"],
        "run_at": "document_idle"
    }],
    "options_page": "welcome.html",
    "browser_specific_settings": {
        "gecko": {"id": "pageai-gemini@example.invalid", "strict_min_version": "109.0"}
    }
}
for folder, manifest in ((chrome, chrome_manifest), (firefox, firefox_manifest)):
    (folder / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (folder / "background.js").write_text((SRC / "background.js").read_text(encoding="utf-8"), encoding="utf-8")

print("Built Chromium and Firefox extension folders.")
