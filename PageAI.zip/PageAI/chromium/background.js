const api = globalThis.browser || globalThis.chrome;

api.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    const url = api.runtime.getURL("welcome.html");
    if (api.tabs && api.tabs.create) api.tabs.create({ url });
  }
});

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "PAGEAI_OPEN_WELCOME") {
    api.tabs.create({ url: api.runtime.getURL("welcome.html") });
    sendResponse({ ok: true });
  }
  return true;
});
