const api = globalThis.browser || globalThis.chrome;
const $ = id => document.getElementById(id);
const get = keys => new Promise(resolve => api.storage.local.get(keys, resolve));
const set = values => new Promise(resolve => api.storage.local.set(values, resolve));
let current = 0;
let tested = false;

function render() {
  document.querySelectorAll(".step").forEach((el, i) => el.classList.toggle("active", i === current));
  $("stepcount").textContent = `STEP ${current + 1} OF 4`;
  $("progressFill").style.width = `${(current + 1) * 25}%`;
  $("back").disabled = current === 0;
  $("next").textContent = current === 3 ? "Finish setup" : "Continue";
  document.querySelectorAll(".dots i").forEach((el, i) => el.classList.toggle("current", i === current));
  if (current === 3) $("readyModel").textContent = $("model").value.trim() || "Gemini model";
}
async function testConnection() {
  const key = $("apiKey").value.trim();
  const model = $("model").value.trim() || "gemini-2.5-flash";
  if (!key) { $("testStatus").textContent = "Paste your API key first."; return false; }
  $("test").disabled = true;
  $("testStatus").textContent = "Testing your Gemini connection…";
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({contents:[{role:"user",parts:[{text:"Reply with exactly: PageAI connection successful."}]}],generationConfig:{maxOutputTokens:30,temperature:0}})
    });
    const data = await res.json().catch(()=>({}));
    if (!res.ok) throw new Error(data?.error?.message || `HTTP ${res.status}`);
    tested = true;
    $("testStatus").textContent = "✓ Connected successfully. Your API key works.";
    $("testStatus").style.color = "#8ff0ba";
    return true;
  } catch (e) {
    tested = false;
    $("testStatus").textContent = `Connection failed: ${e.message}`;
    $("testStatus").style.color = "#fca5a5";
    return false;
  } finally { $("test").disabled = false; }
}
$("toggleKey").addEventListener("click", () => {
  const input = $("apiKey");
  input.type = input.type === "password" ? "text" : "password";
  $("toggleKey").textContent = input.type === "password" ? "Show" : "Hide";
});
$("test").addEventListener("click", testConnection);
$("apiKey").addEventListener("input", () => { tested = false; $("testStatus").textContent = ""; });
$("model").addEventListener("input", () => { tested = false; $("testStatus").textContent = ""; });
$("back").addEventListener("click", () => { if (current > 0) { current--; render(); } });
$("next").addEventListener("click", async () => {
  if (current === 1) {
    if (!$("apiKey").value.trim()) { $("testStatus").textContent = "Add your API key before continuing."; return; }
    if (!tested && !(await testConnection())) return;
  }
  if (current < 3) { current++; render(); return; }
  const behaviour = document.querySelector('input[name="behaviour"]:checked')?.value || "manual";
  await set({
    geminiApiKey: $("apiKey").value.trim(),
    geminiModel: $("model").value.trim() || "gemini-2.5-flash",
    onboardingComplete: true,
    behaviour
  });
  $("next").textContent = "Setup complete ✓";
  $("next").disabled = true;
  $("stepcount").textContent = "PAGEAI IS READY";
  setTimeout(() => window.close(), 900);
});

(async () => {
  const saved = await get(["geminiApiKey", "geminiModel", "onboardingComplete"]);
  if (saved.geminiApiKey) $("apiKey").value = saved.geminiApiKey;
  if (saved.geminiModel) $("model").value = saved.geminiModel;
  if (saved.onboardingComplete && saved.geminiApiKey) {
    $("stepcount").textContent = "SETTINGS";
    $("next").textContent = "Save settings";
    $("apiKey").value = saved.geminiApiKey;
    current = 1;
  }
  render();
})();
