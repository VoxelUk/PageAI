(() => {
  const api = globalThis.browser || globalThis.chrome;
  let panel;

  function ensurePanel() {
    if (panel && panel.isConnected) return panel;
    panel = document.createElement("section");
    panel.id = "pageai-floating-panel";
    panel.setAttribute("style", [
      "position:fixed!important", "z-index:2147483647!important",
      "top:18px!important", "right:18px!important", "width:360px!important",
      "max-width:calc(100vw - 36px)!important", "max-height:75vh!important",
      "overflow:auto!important", "background:#111019!important", "color:#f5f3ff!important",
      "border:1px solid #51456b!important", "border-radius:16px!important",
      "box-shadow:0 18px 60px rgba(0,0,0,.45)!important",
      "font:14px/1.5 system-ui,sans-serif!important", "padding:16px!important",
      "box-sizing:border-box!important"
    ].join(";"));
    const shadow = panel.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box} .top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
        .brand{font-weight:800;font-size:16px;letter-spacing:.2px}.tag{color:#c4b5fd;font-size:11px}
        button{border:0;border-radius:9px;padding:7px 10px;background:#2a2438;color:#fff;cursor:pointer}
        .close{font-size:18px;padding:2px 8px}.answer{white-space:pre-wrap;overflow-wrap:anywhere;color:#e9e5f5}
        .status{color:#c4b5fd;font-size:12px;margin-bottom:8px}
        .foot{border-top:1px solid #332b43;margin-top:12px;padding-top:9px;color:#a9a2b8;font-size:11px}
      </style>
      <div class="top"><div><div class="brand">✦ PageAI</div><div class="tag">GEMINI PAGE ASSISTANT</div></div><button class="close" aria-label="Close">×</button></div>
      <div class="status">Your answer</div><div class="answer"></div>
      <div class="foot">AI can make mistakes. Check important information.</div>`;
    shadow.querySelector(".close").addEventListener("click", () => panel.remove());
    (document.documentElement || document.body).appendChild(panel);
    return panel;
  }

  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "PAGEAI_GET_PAGE") {
      const text = (document.body?.innerText || document.documentElement?.innerText || "")
        .replace(/\n{3,}/g, "\n\n").slice(0, 18000);
      sendResponse({
        ok: true,
        title: document.title || "Untitled page",
        url: location.href,
        text
      });
      return true;
    }
    if (message?.type === "PAGEAI_SHOW_ANSWER") {
      const p = ensurePanel();
      const root = p.shadowRoot;
      root.querySelector(".status").textContent = message.status || "Gemini's answer";
      root.querySelector(".answer").textContent = message.answer || "";
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });
})();
